﻿using System;

namespace MRSDistCompWebApp.Models
{
    public class ComputationInfoParticipant
    {
        public string Id { get; set; }

        public string ComputationInfoName { get; set; }

        public string ParticipantName { get; set; }

        public string IsEnabled { get; set; }
    }
}

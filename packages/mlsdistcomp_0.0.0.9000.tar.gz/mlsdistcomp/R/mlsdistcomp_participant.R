#' @importFrom mlsdistcomp

registerMaster <- function(name, clientid, tenantid, url, clientsecret) {
  require(stringr)
  require(uuid)
  require(lubridate)
  require(httr)
  require(jsonlite)
  require(curl)
  require(RODBC)
  require(R6)

  participantObj <- Participant$new()
  participants = participantObj$getParticipants()

  # Only one Participant record exists on site - that of master.
  # Check and delete if any.
  if(!is.null(participants) && nrow(participants) > 0){

    participantObj$deleteParticipants()
  }

  # Re-register the master
  Id <- participantObj$registerParticipant(name,
                                           clientid,
                                           tenantid,
                                           url,
                                           clientsecret)

  participantObj$finalize()

  return(Id)
}

api_registerMaster <- publishService(
  "RegisterMaster",
  code = registerMaster,
  model = "MRSDistComp.R",
  inputs = list(name = "character",
                clientid = "character",
                tenantid = "character",
                url = "character",
                clientsecret = "character"),
  outputs = list(Id = "character"),
  v = "v1"
)


processJob <- function(projectname, jobid, method, methodparams) {
  require(stringr)
  require(uuid)
  require(lubridate)
  require(httr)
  require(jsonlite)
  require(curl)
  require(RODBC)
  require(R6)
  require(rlist)
  require(distcomp)

  resultNumeric = NA
  resultList = list()
  resultType = NULL

  computationInfoJobObj <- ComputationInfoJob$new()
  print("Invoke ProcessJob")
  resultDataFrame <- computationInfoJobObj$processJob(jobid, projectname, method, methodparams)
  computationInfoJobObj$finalize()
  return(Result=resultDataFrame)
}

api_processJob <- publishService(
  "ProcessJob",
  code = processJob,
  model = "MRSDistComp.R",
  inputs = list(projectname = "character",
                jobid = "character",
                method = "character",
                methodparams = "character"),
  outputs = list(Result = "data.frame"),
  v = "v1"
)


#
#
#
ackProposeComputation <- function(sitename,
                                  projectname,
                                  projectdesc,
                                  formula,
                                  schemaname,
                                  computationtype) {
  require(stringr)
  require(uuid)
  require(lubridate)
  require(httr)
  require(jsonlite)
  require(curl)
  require(RODBC)
  require(R6)

  # Verify if computation type exists
  computationObj <- Computation$new()
  computationsDataFrame = computationObj$getComputations()
  computationObj$finalize()
  if(nrow(computationsDataFrame) == 0){
    stop(sprintf("No computation types were found in the site '%s'. Define computations before proceeding.", sitename))
  }

  if(!any(computationsDataFrame$Name==computationtype)){
    stop(sprintf("Computation type with name '%s' NOT found at site '%s'.", computationtype, sitename))
  }

  # Verify if schema exists for the computation
  schemaObj <- DataCatalog$new()
  schemaDataFrame = schemaObj$getSchemaByName(schemaname)
  schemaObj$finalize()
  if(nrow(schemaDataFrame) == 0){
    stop(sprintf("Schema '%s' not defined at site. Define schema before proposing a computation.", schemaname))
  }

  # Create computation at Site
  ComputationInfoObj <- ComputationInfo$new()
  computationInfoDataFrame = ComputationInfoObj$getComputationInfoByName(projectname)
  if(nrow(computationInfoDataFrame) > 0){
    stop(sprintf("Computation project '%s' is already defined. Proposing computation with a different name.", projectname))
  }

  id <- ComputationInfoObj$createComputationInfo(projectname,
                                           projectdesc,
                                           formula,
                                           schemaname,
                                           computationtype)
  Result <- sprintf("Computation broadcast to site '%s' was successful. Proposed computation registered on site with id '%s'", sitename, id)
  ComputationInfoObj$finalize()
  return(Result)
}

api_ackProposeComputation <- publishService(
  "AckProposeComputation",
  code = ackProposeComputation,
  model = "MRSDistComp.R",
  inputs = list(sitename = "character",
                projectname = "character",
                projectdesc = "character",
                formula = "character",
                schemaname = "character",
                computationtype = "character"),
  outputs = list(Result = "character"),
  v = "v1"
)

#
#
#
ackSchemaRegistration <- function(sitename,
                                  schemaname,
                                  schemadesc,
                                  schema) {
  require(stringr)
  require(uuid)
  require(lubridate)
  require(httr)
  require(jsonlite)
  require(curl)
  require(RODBC)
  require(R6)

  # Verify if computation type exists
  computationObj <- Computation$new()
  computationsDataFrame = computationObj$getComputations()
  computationObj$finalize()
  if(nrow(computationsDataFrame) == 0){
    stop(sprintf("No computation types were found in the site '%s'. Define computations before proceeding.", sitename))
  }

  Result = NULL
  # Verify if schema exists for the computation
  dataCatalogObj <- DataCatalog$new()
  dataCatalogDataFrame = dataCatalogObj$getSchemaByName(schemaname)
  if(nrow(dataCatalogDataFrame) != 0){
    stop(sprintf("Schema '%s' is already defined at site '%s'", schemaname, sitename))
  }

  schemadf <- as.data.frame(fromJSON(schema))
  id <- dataCatalogObj$registerSchema(schemaname,
                                      schemadesc,
                                      schemadf)
  dataCatalogObj$finalize()
  Result <- sprintf("Schema '%s' broadcast to site '%s' was successful. Registered on site with id '%s'.", schemaname, sitename, id)
  return(Result)
}

api_ackSchemaRegistration <- publishService(
  "AckSchemaRegistration",
  code = ackSchemaRegistration,
  model = "MRSDistComp.R",
  inputs = list(sitename = "character",
                schemaname = "character",
                schemadesc = "character",
                schema = "character"),
  outputs = list(Result = "character"),
  v = "v1"
)

#
# Web service to create a new CSV data source
#
createDataSource <- function(schemaname,
                             datasourcename,
                             datasourcedesc,
                             datasourcelocation) {
  require(stringr)
  require(uuid)
  require(lubridate)
  require(httr)
  require(jsonlite)
  require(curl)
  require(RODBC)
  require(R6)

  #
  # Verify if schema of the data source exists
  #
  dataCatlogObj <- DataCatalog$new()
  schemas = dataCatlogObj$getSchemaByName(as.character(schemaname))
  dataCatlogObj$finalize()
  if(is.null(schemas) || nrow(schemas) == 0){
    stop(sprintf("Schema with name '%s' does not exist. Data source can only be configured for existing schemas.", schemaname))
  }

  #
  # Define a CSV data source
  #
  dataSourcesObj <- DataSources$new()
  currentDSDataFrame = dataSourcesObj$getDataSourcesByName(as.character(datasourcename))
  if(!is.null(currentDSDataFrame) && nrow(currentDSDataFrame) > 0){
    stop(sprintf("Datasource with name '%s' already exists.Specify a unique name for the data source.", datasourcename))
  }
  newCSVDSDataFrame <- dataSourcesObj$createCSVDataSource(datasourcename,
                                              datasourcedesc,
                                              schemaname,
                                              datasourcelocation,
                                              ",")
  dataSourcesObj$finalize()
  if(!is.null(newCSVDSDataFrame)) {
    Result <- sprintf("Data source creation '%s' for schema '%s' was successful.", datasourcename, schemaname)
  }
  return(Result)
}

api_createDataSource <- publishService(
  "CreateCSVDataSource",
  code = createDataSource,
  model = "MRSDistComp.R",
  inputs = list(schemaname = "character",
                datasourcename = "character",
                datasourcedesc = "character",
                datasourcelocation = "character"),
  outputs = list(Result = "character"),
  v = "v1"
)

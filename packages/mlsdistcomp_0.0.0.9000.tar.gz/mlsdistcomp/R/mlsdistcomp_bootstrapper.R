#!/usr/bin/env RScript
#' @import mrsdeploy
#' @import here

args = commandArgs(trailingOnly=TRUE)
if (length(args)<4) {

  stop("Expected at least 4 arguments.", call.=FALSE)

} else if (length(args)>=4) {

  profile <- args[1]
  url <- args[2]
  username <- args[3]
  password <- args[4]

  if(length(args)==5){
    fn <- args[5]
  } else{
    fn <- 'register'
  }

  mlsLogin(url=url, username=username, password=password)
  do.call(fn)
}

#' Create a login session for Machine Learning Server
#' A valid MLS session is required for this function to succeeed.
#'
#' @param url url of the Machine Learning Server to connect to
#' @param username username to connect as
#' @param password password for the login user
#'
#' @return
#' @export
#'
#' @examples
mlsLogin <- function(url,
                    username,
                    password) {
  require(mrsdeploy)
  mrsdeploy::remoteLogin(url=url,
                         username=username,
                         password=password,
                         session = FALSE)
}

#' Register services with Machine Learning Server
#' A valid MLS session is required for this function to succeeed.
#'
#' @param profile Profile of the site. Expected "Central" or "Participant".
#'
#' @return None
#' @export
#'
#' @examples
#' register('Central')
register <- function(profile){
  require(mrsdeploy)
  if(strcmpi(profile, "Central")){
    source(here::here('mlsdistcomp_central.R'))
  } else {
    source(here::here('mlsdistcomp_participant.R'))
  }
}

#' Unregister all MLS web services
#'
#' @param profile Profile of the site. Expected "Central" or "Participant".
#'
#' @return None
#' @export
#'
#' @examples
#' unregister('Central')
unregister <- function(profile){
  require(mrsdeploy)

  if(strcmpi(profile, "Central")) {
    deleteService("RegisterComputations", "v1")
    deleteService("GetParticipants", "v1")
    deleteService("RegisterParticipant", "v1")
    deleteService("GetSchemas", "v1")
    deleteService("RegisterSchema", "v1")
    deleteService("GetComputationProjects", "v1")
    deleteService("ProposeComputation", "v1")
    deleteService("EnrollInProject", "v1")
    deleteService("TriggerJob", "v1")
    deleteService("GetJobInfo", "v1")
    deleteService("GetProjectJobs", "v1")
  } else{
    deleteService("RegisterMaster", "v1")
    deleteService("AckSchemaRegistration", "v1")
    deleteService("CreateCSVDataSource", "v1")
    deleteService("AckProposeComputation", "v1")
    deleteService("ProcessJob", "v1")
  }
}

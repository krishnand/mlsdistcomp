#' @importFrom mlsdistcomp

#' Function that registers computations from distcomp package
#' into the mlsdistcomp backend.
#'
#' @return
#' @export
#'
#' @examples
registerComputations <- function() {
  require(stringr)
  require(uuid)
  require(lubridate)
  require(httr)
  require(jsonlite)
  require(curl)
  require(RODBC)
  require(R6)

  computationObj <- Computation$new()
  resultList <- computationObj$registerAllComputations()
  computationObj$finalize()
  Result <- paste0("The following computations were registered: ", print(resultList, row.names = FALSE))
  return(Result)
}

api_registerComputations <- publishService(
  "RegisterComputations",
  code = registerComputations,
  model = "MRSDistComp.R",
  inputs = list(),
  outputs = list(Result = "character"),
  v = "v1"
)

getParticipants <- function() {
  require(stringr)
  require(uuid)
  require(lubridate)
  require(httr)
  require(jsonlite)
  require(curl)
  require(RODBC)
  require(R6)

  participantObj <- Participant$new()
  participants = participantObj$getParticipants()
  Result = apply(participants, 1, list)
  participantObj$finalize()
  return(Result)
}

api_getParticipants <- publishService(
  "GetParticipants",
  code = getParticipants,
  model = "MRSDistComp.R",
  inputs = list(),
  outputs = list(Result = "data.frame"),
  v = "v1"
)

#
# Participant::RegisterParticipant
#
registerParticipant <- function(name, clientid, tenantid, url, clientsecret) {
  require(stringr)
  require(uuid)
  require(lubridate)
  require(httr)
  require(jsonlite)
  require(curl)
  require(RODBC)
  require(R6)

  participantObj <- Participant$new()
  participants = participantObj$getParticipants()

  # Delete the participant if it exists.
  if(!is.null(participants) && nrow(participants) > 0){
    print("Participant exists. Removing...")
    participantObj$deleteParticipants(as.character(name))
  }

  print(sprintf("Re-registering participant '%s'...", name))
  Id <- participantObj$registerParticipant(name,
                                           clientid,
                                           tenantid,
                                           url,
                                           clientsecret)
  participantObj$finalize()
  print("Participant registration was successful.")
  return(Id)
}

api_registerParticipant <- publishService(
  "RegisterParticipant",
  code = registerParticipant,
  model = "MRSDistComp.R",
  inputs = list(name = "character",
                clientid = "character",
                tenantid = "character",
                url = "character",
                clientsecret = "character"),
  outputs = list(Id = "character"),
  v = "v1"
)

#
# DataCatalog::GetSchemas
#
getSchemas <- function(schemaname) {
  require(stringr)
  require(uuid)
  require(lubridate)
  require(httr)
  require(jsonlite)
  require(curl)
  require(RODBC)
  require(R6)

  dataCatalogObj <- DataCatalog$new()
  if(is.null(schemaname) || schemaname == ""){
    schemas = dataCatalogObj$getSchemaByName()
  }
  else{
    schemas = dataCatalogObj$getSchemaByName(schemaname)
  }
  Result = apply(schemas, 1, list)
  dataCatalogObj$finalize()
  return(Result)
}

api_getSchemas <- publishService(
  "GetSchemas",
  code = getSchemas,
  model = "MRSDistComp.R",
  inputs = list(schemaname = "character"),
  outputs = list(Result = "data.frame"),
  v = "v1"
)

#
# DataCatalog::RegisterSchema
#
registerSchema <- function(schemaname, schemadesc, schema, broadcast) {
  require(stringr)
  require(uuid)
  require(lubridate)
  require(httr)
  require(jsonlite)
  require(curl)
  require(RODBC)
  require(R6)

  Result = NULL
  # Verify if schema exists for the computation
  dataCatalogObj <- DataCatalog$new()
  dataCatalogDataFrame = dataCatalogObj$getSchemaByName(schemaname)
  if(nrow(dataCatalogDataFrame) != 0){
    stop(sprintf("Schema '%s' defined already. Define schema with a different name.", schemaname))
  }

  schemadf <- as.data.frame(fromJSON(schema))
  id <- dataCatalogObj$registerSchema(schemaname,
                                 schemadesc,
                                 schemadf)
  dataCatalogObj$finalize()
  Result = sprintf("Schema '%s' registered successfully.", schemaname)

  if(as.logical(broadcast)) {

    # Refresh all participant tokens. No ROI with optimizing this.
    print("Refreshing particpant access tokens...")
    participantsObj = Participant$new()
    participantsObj$refreshAADToken()
    participantsObj$finalize()

    # Broadcast schema to all sites
    workerendpoint= 'AckSchemaRegistration/v1'
    Result = sprintf("Schema '%s' successfully registered across all sites.", schemaname)
    status = dataCatalogObj$broadcastSchemaInfo(schemaname,
                                           schemadesc,
                                           schema,
                                           workerendpoint)
    if(!status){
      Result = "One or more sites could not register the schema. Please review and update."
    }
  }
  return(Result)
}

api_registerSchema <- publishService(
  "RegisterSchema",
  code = registerSchema,
  model = "MRSDistComp.R",
  inputs = list(schemaname = "character",
                schemadesc = "character",
                schema = "character",
                broadcast = "logical"),
  outputs = list(Result = "character"),
  v = "v1"
)

#
# ComputationInfo::GetComputationProjects
#
getComputationProjects <- function(projectname) {
  require(stringr)
  require(uuid)
  require(lubridate)
  require(httr)
  require(jsonlite)
  require(curl)
  require(RODBC)
  require(R6)

  computationInfoObj <- ComputationInfo$new()
  if(projectname != ""){
    computationProjects = ComputationInfoObj$getComputationInfoByName(projectname)
  }else {
    computationProjects = computationInfoObj$getAllComputationInfo()
  }
  Result = apply(computationProjects, 1, list)
  computationInfoObj$finalize()
  return(Result)
}

api_getgetComputationProjects <- publishService(
  "GetComputationProjects",
  code = getComputationProjects,
  model = "MRSDistComp.R",
  inputs = list(projectname = "character"),
  outputs = list(Result = "data.frame"),
  v = "v1"
)

#
# Service to propose a new computation project (ComputationInfo) and broadcast it
# to all participants.
#
proposeComputation <- function(projectname,
                               projectdesc,
                               formula,
                               schemaname,
                               computationtype,
                               broadcast) {
  require(stringr)
  require(uuid)
  require(lubridate)
  require(httr)
  require(jsonlite)
  require(curl)
  require(RODBC)
  require(R6)

  # Verify if computation type exists
  computationObj <- Computation$new()
  computationsDataFrame = computationObj$getComputations()
  computationObj$finalize()
  if(nrow(computationsDataFrame) == 0){
    stop("No computation types were found in the MASTER. Computations must be defined before proceeding.")
  }

  if(!any(computationsDataFrame$Name==computationtype)){
    stop(sprintf("Computation type with name '%s' NOT found. Use appropriate computation type before proceeding.", computationtype))
  }

  # Verify if schema exists for the computation
  schemaObj <- DataCatalog$new()
  schemaDataFrame = schemaObj$getSchemaByName(schemaname)
  schemaObj$finalize()
  if(nrow(schemaDataFrame) == 0){
    stop(sprintf("Schema '%s' not defined. Define schema before proposing a new computation.", schemaname))
  }

  # Create computation at Master
  computationInfoObj <- ComputationInfo$new()
  computationInfoDataFrame = computationInfoObj$getComputationInfoByName(projectname)
  if(nrow(computationInfoDataFrame) > 0){
    stop(sprintf("Computation project '%s' is already defined. Please propose computation with a different name.", projectname))
  }

  id = computationInfoObj$createComputationInfo(projectname,
                                           projectdesc,
                                           formula,
                                           schemaname,
                                           computationtype)
  computationInfoObj$finalize()
  Result = sprintf("Computation project created successfully in MASTER with identifier '%s'", id)

  if(as.logical(broadcast)) {

    # Refresh all participant tokens. No ROI with optimizing this.
    print("Refreshing particpant access tokens...")
    participantsObj = Participant$new()
    participantsObj$refreshAADToken()
    participantsObj$finalize()

    # Broadcast computation to all sites
    workerendpoint= 'AckProposeComputation/v1'
    Result = sprintf("Computation proposal '%s' successfully setup across all sites.", projectname)
    computationInfoObj = ComputationInfo$new()
    status = computationInfoObj$broadcastComputationInfo(projectname,
                                                projectdesc,
                                                formula,
                                                schemaname,
                                                computationtype,
                                                workerendpoint)
    computationInfoObj$finalize()
    if(!status){
      Result = "One or more sites could not accept proposed computation. Please review and update."
    }
  }
  return(Result)
}

api_proposeComputation <- publishService(
  "ProposeComputation",
  code = proposeComputation,
  model = "MRSDistComp.R",
  inputs = list(projectname = "character",
                projectdesc = "character",
                formula = "character",
                schemaname = "character",
                computationtype = "character",
                broadcast = "logical"),
  outputs = list(Result = "character"),
  v = "v1"
)

#
# Service to enroll a participant in a project
#
enrollInProject <- function(projectname,
                            participantname) {
  require(stringr)
  require(uuid)
  require(lubridate)
  require(httr)
  require(jsonlite)
  require(curl)
  require(RODBC)
  require(R6)

  # Verify project exists
  computationInfoObj <- ComputationInfo$new()
  computationInfoDataFrame = computationInfoObj$getComputationInfoByName(projectname)
  if(is.null(computationInfoDataFrame) || nrow(computationInfoDataFrame) == 0){
    stop(sprintf("Computation project '%s' is NOT defined. Specify a valid projectname or create one before proceeding.", projectname))
  }
  computationInfoObj$finalize()

  #
  # Enroll participant in project
  #

  projectParticipantsObj <- ComputationInfoParticipants$new()
  projectParticipantsDataFrame = projectParticipantsObj$getParticipantsOfAProject(projectname)
  if(is.null(projectParticipantsDataFrame) || nrow(projectParticipantsDataFrame) == 0){

      projectParticipantsObj$create(projectname, participantname)
      sprintf("Particpant '%s' successfully enrolled in project '%s'.", participantname, projectname)

  } else {
    sprintf("Particpant '%s' is already enrolled in project '%s'.", participantname, projectname)
  }
}

api_enrollInProject <- publishService(
  "EnrollInProject",
  code = enrollInProject,
  model = "MRSDistComp.R",
  inputs = list(projectname = "character",
                participantname = "character"),
  v = "v1"
)

#
# ComputationInfoJob::TriggerJob
#
triggerJob <- function(projectname, jobid) {
  require(stringr)
  require(uuid)
  require(lubridate)
  require(httr)
  require(jsonlite)
  require(curl)
  require(RODBC)
  require(R6)
  require(distcomp)

  # Refresh all participant tokens. No ROI with optimizing this.
  print("Refreshing particpant access tokens...")
  participantsObj = Participant$new()
  participantsObj$refreshAADToken()
  participantsObj$finalize()

  # DEFAULTING!!!!.. Expected to be same for all worker nodes or this must be parameterized into
  # participants if they want to expose different processing endpoints.
  workerendpointname <- 'ProcessJob/v1'

  computationInfoJobObj <- ComputationInfoJob$new()
  Result <- computationInfoJobObj$triggerJob(projectname, jobid, workerendpointname)
  computationInfoJobObj$finalize()
  return(Result)
}

api_triggerJob <- publishService(
  "TriggerJob",
  code = triggerJob,
  model = "MRSDistComp.R",
  inputs = list(projectname = "character",
                jobid = "character"),
  outputs = list(Result = "character"),
  v = "v1"
)


#
# ComputationInfoJob::GetJobInfo
#
getJobInfo <- function(jobid) {
  require(stringr)
  require(uuid)
  require(lubridate)
  require(httr)
  require(jsonlite)
  require(curl)
  require(RODBC)
  require(R6)
  require(distcomp)

  computationInfoJobObj <- ComputationInfoJob$new()
  Result <- computationInfoJobObj$getJobById(jobid)

  # Removing logtxt and operation columns
  dropcols <- c("LogTxt","Operation")

  computationInfoJobObj$finalize()
  return(Result[ , !(names(Result) %in% dropcols)])
}

api_getJobInfo <- publishService(
  "GetJobInfo",
  code = getJobInfo,
  model = "MRSDistComp.R",
  inputs = list(jobid = "character"),
  outputs = list(Result = "data.frame"),
  v = "v1"
)

#
# ComputationInfoJob::GetProjectJobs
#
getProjectJobs <- function(projectname) {
  require(stringr)
  require(uuid)
  require(lubridate)
  require(httr)
  require(jsonlite)
  require(curl)
  require(RODBC)
  require(R6)
  require(distcomp)

  computationInfoJobObj <- ComputationInfoJob$new()
  computationInfoJobs <- computationInfoJobObj$getJobsForProject(projectname)
  Result = apply(computationInfoJobs, 1, list)
  computationInfoJobObj$finalize()
  return(Result)
}

api_getProjectJobs <- publishService(
  "GetProjectJobs",
  code = getProjectJobs,
  model = "MRSDistComp.R",
  inputs = list(projectname = "character"),
  outputs = list(Result = "data.frame"),
  v = "v1"
)

secrets = list(
  server = "",
  database = "",
  user = "",
  password = ""
)

computeContext = list(
  datafolder = tempdir()
)

tokenCacheFilePath = paste0(computeContext$datafolder, "/MRSDistCompTokenCache.CSV")
